<?php

namespace YourVendor\Racing\Listeners;

use Flarum\Api\Serializer\CurrentUserSerializer;
use Flarum\User\User;
use YourVendor\Racing\Services\WalletService;

class AddUserAttributes
{
    public function __construct(private WalletService $wallet) {}

    public function __invoke(CurrentUserSerializer $serializer, User $user, array $attributes): array
    {
        $attributes['racingCoins'] = $this->wallet->getBalance($user->id);
        return $attributes;
    }
}
