<?php

namespace YourVendor\Racing\Listeners;

use Flarum\Post\Event\Posted;
use YourVendor\Racing\Services\WalletService;

class GiveCoinsOnPost
{
    public function __construct(private WalletService $wallet) {}

    public function handle(Posted $event): void
    {
        $userId = $event->post->user_id;
        if ($userId) {
            $this->wallet->addCoins($userId, 5); // +5 coins per post
        }
    }
}
