<?php

namespace YourVendor\Racing\Services;

class RaceEngine
{
    /**
     * Simulate a race between two cars.
     * Returns ['winner' => 'challenger'|'challenged', 'log' => [...]]
     */
    public function simulate(array $challengerCar, array $challengedCar): array
    {
        $log = [];
        $segments = 5; // Race has 5 segments

        $challengerScore = 0;
        $challengedScore = 0;

        for ($i = 1; $i <= $segments; $i++) {
            $cResult = $this->segmentScore($challengerCar);
            $dResult = $this->segmentScore($challengedCar);

            if ($cResult > $dResult) {
                $challengerScore++;
                $log[] = [
                    'segment' => $i,
                    'leader' => 'challenger',
                    'challenger_roll' => $cResult,
                    'challenged_roll' => $dResult,
                    'event' => $this->randomEvent($challengerCar['name'], true),
                ];
            } elseif ($dResult > $cResult) {
                $challengedScore++;
                $log[] = [
                    'segment' => $i,
                    'leader' => 'challenged',
                    'challenger_roll' => $cResult,
                    'challenged_roll' => $dResult,
                    'event' => $this->randomEvent($challengedCar['name'], true),
                ];
            } else {
                // Tie - luck decides
                $luckyWinner = ($challengerCar['luck'] >= $challengedCar['luck']) ? 'challenger' : 'challenged';
                if ($luckyWinner === 'challenger') $challengerScore++;
                else $challengedScore++;
                $log[] = [
                    'segment' => $i,
                    'leader' => $luckyWinner,
                    'challenger_roll' => $cResult,
                    'challenged_roll' => $dResult,
                    'event' => 'Dead heat! Luck decides...',
                ];
            }
        }

        $winner = $challengerScore >= $challengedScore ? 'challenger' : 'challenged';

        $log[] = [
            'segment' => 'finish',
            'challenger_segments' => $challengerScore,
            'challenged_segments' => $challengedScore,
            'winner' => $winner,
        ];

        return [
            'winner' => $winner,
            'challenger_score' => $challengerScore,
            'challenged_score' => $challengedScore,
            'log' => $log,
        ];
    }

    private function segmentScore(array $car): float
    {
        // Weighted random based on stats + luck factor
        $base = ($car['speed'] * 0.4) + ($car['acceleration'] * 0.3) + ($car['handling'] * 0.2);
        $luckBonus = (mt_rand(0, $car['luck']) / 100) * 20;
        $randomFactor = mt_rand(-10, 10);

        return round($base + $luckBonus + $randomFactor, 2);
    }

    private function randomEvent(string $carName, bool $winning): string
    {
        $winningEvents = [
            "{$carName} takes the inside line perfectly!",
            "{$carName} rockets ahead on the straight!",
            "{$carName} finds a gap and pushes through!",
            "{$carName} nails the apex and pulls away!",
            "{$carName} driver shows expert skill!",
        ];

        $losingEvents = [
            "{$carName} loses grip momentarily!",
            "{$carName} brakes slightly too late!",
            "{$carName} struggles through the chicane!",
        ];

        $events = $winning ? $winningEvents : $losingEvents;
        return $events[array_rand($events)];
    }
}
