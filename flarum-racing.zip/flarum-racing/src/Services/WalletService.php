<?php

namespace YourVendor\Racing\Services;

use Illuminate\Database\ConnectionInterface;

class WalletService
{
    public function __construct(private ConnectionInterface $db) {}

    public function getBalance(int $userId): int
    {
        $wallet = $this->db->table('racing_wallets')->where('user_id', $userId)->first();
        if (!$wallet) {
            $this->db->table('racing_wallets')->insert([
                'user_id' => $userId,
                'balance' => 50, // Starting bonus
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            return 50;
        }
        return (int) $wallet->balance;
    }

    public function addCoins(int $userId, int $amount): int
    {
        $this->ensureWallet($userId);
        $this->db->table('racing_wallets')
            ->where('user_id', $userId)
            ->increment('balance', $amount, ['updated_at' => now()]);
        return $this->getBalance($userId);
    }

    public function deductCoins(int $userId, int $amount): bool
    {
        $balance = $this->getBalance($userId);
        if ($balance < $amount) return false;

        $this->db->table('racing_wallets')
            ->where('user_id', $userId)
            ->decrement('balance', $amount, ['updated_at' => now()]);
        return true;
    }

    public function transfer(int $fromId, int $toId, int $amount): bool
    {
        if (!$this->deductCoins($fromId, $amount)) return false;
        $this->addCoins($toId, $amount);
        return true;
    }

    private function ensureWallet(int $userId): void
    {
        $exists = $this->db->table('racing_wallets')->where('user_id', $userId)->exists();
        if (!$exists) {
            $this->db->table('racing_wallets')->insert([
                'user_id' => $userId,
                'balance' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
