<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\RaceEngine;
use YourVendor\Racing\Services\WalletService;

class AcceptChallengeController implements RequestHandlerInterface
{
    public function __construct(
        private ConnectionInterface $db,
        private WalletService $wallet,
        private RaceEngine $engine,
    ) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $challengeId = (int) $request->getAttribute('id');
        $body = $request->getParsedBody();
        $myCarId = (int) ($body['car_id'] ?? 0);

        if (!$myCarId) {
            return new JsonResponse(['error' => 'Select a car'], 422);
        }

        $challenge = $this->db->table('racing_challenges')
            ->where('id', $challengeId)
            ->where('status', 'pending')
            ->first();

        if (!$challenge) {
            return new JsonResponse(['error' => 'Challenge not found or already completed'], 404);
        }

        if ($challenge->challenger_id === $actor->id) {
            return new JsonResponse(['error' => 'Cannot accept your own challenge'], 422);
        }

        if ($challenge->challenged_id && $challenge->challenged_id !== $actor->id) {
            return new JsonResponse(['error' => 'This challenge is not for you'], 403);
        }

        // Verify car
        $myCar = $this->db->table('racing_user_cars')
            ->where('id', $myCarId)
            ->where('user_id', $actor->id)
            ->first();

        if (!$myCar) {
            return new JsonResponse(['error' => 'Car not found in your garage'], 404);
        }

        // Check bet funds
        if ($challenge->bet > 0) {
            $myBalance = $this->wallet->getBalance($actor->id);
            if ($myBalance < $challenge->bet) {
                return new JsonResponse(['error' => 'Insufficient coins to match bet'], 422);
            }
        }

        // Load car stats
        $challengerCarData = $this->getCarStats($challenge->challenger_car_id);
        $challengedCarData = $this->getCarStats($myCarId);

        // Run race
        $result = $this->engine->simulate($challengerCarData, $challengedCarData);

        $winnerId = $result['winner'] === 'challenger' ? $challenge->challenger_id : $actor->id;
        $loserId = $result['winner'] === 'challenger' ? $actor->id : $challenge->challenger_id;
        $winnerCarId = $result['winner'] === 'challenger' ? $challenge->challenger_car_id : $myCarId;
        $loserCarId = $result['winner'] === 'challenger' ? $myCarId : $challenge->challenger_car_id;

        // Persist result
        $raceId = $this->db->table('racing_races')->insertGetId([
            'challenge_id' => $challengeId,
            'winner_id' => $winnerId,
            'loser_id' => $loserId,
            'winner_car_id' => $winnerCarId,
            'loser_car_id' => $loserCarId,
            'prize' => $challenge->bet * 2,
            'race_log' => json_encode($result['log']),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Update challenge status
        $this->db->table('racing_challenges')
            ->where('id', $challengeId)
            ->update(['status' => 'completed', 'challenged_car_id' => $myCarId, 'updated_at' => now()]);

        // Update car stats
        $this->db->table('racing_user_cars')->where('id', $winnerCarId)->increment('races_won');
        $this->db->table('racing_user_cars')->whereIn('id', [$winnerCarId, $loserCarId])->increment('races_total');

        // Handle bet payout
        if ($challenge->bet > 0) {
            $this->wallet->deductCoins($loserId, $challenge->bet);
            $this->wallet->addCoins($winnerId, $challenge->bet);
        }

        $iWon = $winnerId === $actor->id;

        return new JsonResponse([
            'success' => true,
            'race_id' => $raceId,
            'winner' => $result['winner'],
            'i_won' => $iWon,
            'challenger_score' => $result['challenger_score'],
            'challenged_score' => $result['challenged_score'],
            'log' => $result['log'],
            'prize' => $challenge->bet > 0 ? $challenge->bet : 0,
            'my_new_balance' => $this->wallet->getBalance($actor->id),
        ]);
    }

    private function getCarStats(int $userCarId): array
    {
        $row = $this->db->table('racing_user_cars as uc')
            ->join('racing_car_catalog as cc', 'uc.car_catalog_id', '=', 'cc.id')
            ->where('uc.id', $userCarId)
            ->select(['cc.name', 'cc.speed', 'cc.acceleration', 'cc.handling', 'cc.luck'])
            ->first();

        return [
            'name' => $row->name,
            'speed' => $row->speed,
            'acceleration' => $row->acceleration,
            'handling' => $row->handling,
            'luck' => $row->luck,
        ];
    }
}
