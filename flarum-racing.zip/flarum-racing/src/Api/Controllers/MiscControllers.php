<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\WalletService;

class RaceController implements RequestHandlerInterface
{
    public function __construct(private ConnectionInterface $db) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $raceId = (int) $request->getAttribute('id');

        $race = $this->db->table('racing_races as r')
            ->join('racing_challenges as rc', 'r.challenge_id', '=', 'rc.id')
            ->join('users as wu', 'r.winner_id', '=', 'wu.id')
            ->join('users as lu', 'r.loser_id', '=', 'lu.id')
            ->join('racing_user_cars as wuc', 'r.winner_car_id', '=', 'wuc.id')
            ->join('racing_car_catalog as wcc', 'wuc.car_catalog_id', '=', 'wcc.id')
            ->join('racing_user_cars as luc', 'r.loser_car_id', '=', 'luc.id')
            ->join('racing_car_catalog as lcc', 'luc.car_catalog_id', '=', 'lcc.id')
            ->where('r.id', $raceId)
            ->select([
                'r.id',
                'r.prize',
                'r.race_log',
                'r.created_at',
                'wu.username as winner_name',
                'lu.username as loser_name',
                'wcc.name as winner_car',
                'wcc.emoji as winner_emoji',
                'wcc.color as winner_color',
                'lcc.name as loser_car',
                'lcc.emoji as loser_emoji',
                'lcc.color as loser_color',
            ])
            ->first();

        if (!$race) {
            return new JsonResponse(['error' => 'Race not found'], 404);
        }

        return new JsonResponse([
            'race' => [
                'id' => $race->id,
                'prize' => $race->prize,
                'created_at' => $race->created_at,
                'winner' => ['name' => $race->winner_name, 'car' => $race->winner_car, 'emoji' => $race->winner_emoji, 'color' => $race->winner_color],
                'loser' => ['name' => $race->loser_name, 'car' => $race->loser_car, 'emoji' => $race->loser_emoji, 'color' => $race->loser_color],
                'log' => json_decode($race->race_log, true),
            ],
        ]);
    }
}

class LeaderboardController implements RequestHandlerInterface
{
    public function __construct(private ConnectionInterface $db) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $leaderboard = $this->db->table('racing_races')
            ->join('users', 'racing_races.winner_id', '=', 'users.id')
            ->select([
                'users.id',
                'users.username',
                $this->db->raw('COUNT(*) as wins'),
            ])
            ->groupBy('users.id', 'users.username')
            ->orderByDesc('wins')
            ->limit(20)
            ->get();

        // Add total races and win rate
        $result = $leaderboard->map(function ($row) {
            $total = $this->db->table('racing_races')
                ->where('winner_id', $row->id)
                ->orWhere('loser_id', $row->id)
                ->count();

            return [
                'user_id' => $row->id,
                'username' => $row->username,
                'wins' => $row->wins,
                'total_races' => $total,
                'win_rate' => $total > 0 ? round(($row->wins / $total) * 100, 1) : 0,
            ];
        });

        return new JsonResponse(['leaderboard' => $result]);
    }
}

class WalletController implements RequestHandlerInterface
{
    public function __construct(private WalletService $wallet) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        return new JsonResponse([
            'balance' => $this->wallet->getBalance($actor->id),
        ]);
    }
}
