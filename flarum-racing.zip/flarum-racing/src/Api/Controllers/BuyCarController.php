<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\WalletService;

class BuyCarController implements RequestHandlerInterface
{
    public function __construct(
        private ConnectionInterface $db,
        private WalletService $wallet,
    ) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $body = $request->getParsedBody();
        $catalogId = (int) ($body['car_catalog_id'] ?? 0);

        if (!$catalogId) {
            return new JsonResponse(['error' => 'Invalid car ID'], 422);
        }

        $car = $this->db->table('racing_car_catalog')
            ->where('id', $catalogId)
            ->where('available', true)
            ->first();

        if (!$car) {
            return new JsonResponse(['error' => 'Car not found'], 404);
        }

        // Allow buying duplicates (can race with multiple)
        $balance = $this->wallet->getBalance($actor->id);
        if ($balance < $car->price) {
            return new JsonResponse(['error' => 'Insufficient coins', 'balance' => $balance, 'price' => $car->price], 422);
        }

        if (!$this->wallet->deductCoins($actor->id, $car->price)) {
            return new JsonResponse(['error' => 'Transaction failed'], 500);
        }

        $userCarId = $this->db->table('racing_user_cars')->insertGetId([
            'user_id' => $actor->id,
            'car_catalog_id' => $catalogId,
            'races_total' => 0,
            'races_won' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return new JsonResponse([
            'success' => true,
            'car_id' => $userCarId,
            'balance' => $this->wallet->getBalance($actor->id),
            'message' => "You bought {$car->name}!",
        ]);
    }
}
