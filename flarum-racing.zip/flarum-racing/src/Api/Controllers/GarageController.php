<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\WalletService;

class GarageController implements RequestHandlerInterface
{
    public function __construct(
        private ConnectionInterface $db,
        private WalletService $wallet,
    ) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $cars = $this->db->table('racing_user_cars as uc')
            ->join('racing_car_catalog as cc', 'uc.car_catalog_id', '=', 'cc.id')
            ->where('uc.user_id', $actor->id)
            ->select([
                'uc.id',
                'uc.custom_name',
                'uc.races_total',
                'uc.races_won',
                'cc.name as catalog_name',
                'cc.emoji',
                'cc.color',
                'cc.speed',
                'cc.acceleration',
                'cc.handling',
                'cc.luck',
                'cc.rarity',
            ])
            ->get()
            ->map(function ($car) {
                $winRate = $car->races_total > 0
                    ? round(($car->races_won / $car->races_total) * 100, 1)
                    : 0;

                return [
                    'id' => $car->id,
                    'name' => $car->custom_name ?? $car->catalog_name,
                    'emoji' => $car->emoji,
                    'color' => $car->color,
                    'speed' => $car->speed,
                    'acceleration' => $car->acceleration,
                    'handling' => $car->handling,
                    'luck' => $car->luck,
                    'rarity' => $car->rarity,
                    'races_total' => $car->races_total,
                    'races_won' => $car->races_won,
                    'win_rate' => $winRate,
                ];
            });

        return new JsonResponse([
            'cars' => $cars,
            'balance' => $this->wallet->getBalance($actor->id),
        ]);
    }
}
