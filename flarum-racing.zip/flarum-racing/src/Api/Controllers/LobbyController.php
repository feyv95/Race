<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\WalletService;

class LobbyController implements RequestHandlerInterface
{
    public function __construct(
        private ConnectionInterface $db,
        private WalletService $wallet,
    ) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        // Open challenges (anyone can accept)
        $openChallenges = $this->db->table('racing_challenges as rc')
            ->join('users as u', 'rc.challenger_id', '=', 'u.id')
            ->join('racing_user_cars as uc', 'rc.challenger_car_id', '=', 'uc.id')
            ->join('racing_car_catalog as cc', 'uc.car_catalog_id', '=', 'cc.id')
            ->where('rc.status', 'pending')
            ->whereNull('rc.challenged_id')
            ->where('rc.challenger_id', '!=', $actor->id)
            ->select([
                'rc.id',
                'rc.bet',
                'rc.created_at',
                'u.id as challenger_id',
                'u.username as challenger_name',
                'uc.id as car_id',
                'cc.name as car_name',
                'cc.emoji',
                'cc.color',
                'cc.speed',
                'cc.acceleration',
                'cc.handling',
                'cc.luck',
                'cc.rarity',
            ])
            ->orderBy('rc.created_at', 'desc')
            ->limit(20)
            ->get();

        // Direct challenges TO current user
        $myChallenges = $this->db->table('racing_challenges as rc')
            ->join('users as u', 'rc.challenger_id', '=', 'u.id')
            ->join('racing_user_cars as uc', 'rc.challenger_car_id', '=', 'uc.id')
            ->join('racing_car_catalog as cc', 'uc.car_catalog_id', '=', 'cc.id')
            ->where('rc.status', 'pending')
            ->where('rc.challenged_id', $actor->id)
            ->select([
                'rc.id',
                'rc.bet',
                'rc.created_at',
                'u.id as challenger_id',
                'u.username as challenger_name',
                'uc.id as car_id',
                'cc.name as car_name',
                'cc.emoji',
                'cc.color',
                'cc.speed',
                'cc.acceleration',
                'cc.handling',
                'cc.luck',
                'cc.rarity',
            ])
            ->orderBy('rc.created_at', 'desc')
            ->get();

        // My own open challenges
        $myPostedChallenges = $this->db->table('racing_challenges')
            ->where('challenger_id', $actor->id)
            ->where('status', 'pending')
            ->select(['id', 'bet', 'challenged_id', 'created_at'])
            ->get();

        return new JsonResponse([
            'open_challenges' => $openChallenges,
            'my_challenges' => $myChallenges,
            'my_posted' => $myPostedChallenges,
            'balance' => $this->wallet->getBalance($actor->id),
        ]);
    }
}
