<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\WalletService;

class ShopController implements RequestHandlerInterface
{
    public function __construct(
        private ConnectionInterface $db,
        private WalletService $wallet,
    ) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $catalog = $this->db->table('racing_car_catalog')
            ->where('available', true)
            ->orderByRaw("FIELD(rarity, 'common', 'rare', 'epic', 'legendary')")
            ->get();

        // Mark which cars user already owns
        $ownedCatalogIds = $this->db->table('racing_user_cars')
            ->where('user_id', $actor->id)
            ->pluck('car_catalog_id')
            ->toArray();

        $cars = $catalog->map(function ($car) use ($ownedCatalogIds) {
            return [
                'id' => $car->id,
                'name' => $car->name,
                'emoji' => $car->emoji,
                'color' => $car->color,
                'price' => $car->price,
                'speed' => $car->speed,
                'acceleration' => $car->acceleration,
                'handling' => $car->handling,
                'luck' => $car->luck,
                'rarity' => $car->rarity,
                'owned' => in_array($car->id, $ownedCatalogIds),
            ];
        });

        return new JsonResponse([
            'cars' => $cars,
            'balance' => $this->wallet->getBalance($actor->id),
        ]);
    }
}
