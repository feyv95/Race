<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;

class DeclineChallengeController implements RequestHandlerInterface
{
    public function __construct(private ConnectionInterface $db) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $challengeId = (int) $request->getAttribute('id');

        $challenge = $this->db->table('racing_challenges')
            ->where('id', $challengeId)
            ->where('status', 'pending')
            ->first();

        if (!$challenge) {
            return new JsonResponse(['error' => 'Challenge not found'], 404);
        }

        // Only challenged user or challenger (cancel own) can decline
        if ($challenge->challenged_id !== $actor->id && $challenge->challenger_id !== $actor->id) {
            return new JsonResponse(['error' => 'Forbidden'], 403);
        }

        $this->db->table('racing_challenges')
            ->where('id', $challengeId)
            ->update(['status' => 'declined', 'updated_at' => now()]);

        return new JsonResponse(['success' => true]);
    }
}
