<?php

namespace YourVendor\Racing\Api\Controllers;

use Flarum\Http\RequestUtil;
use Illuminate\Database\ConnectionInterface;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use YourVendor\Racing\Services\WalletService;

class ChallengeController implements RequestHandlerInterface
{
    public function __construct(
        private ConnectionInterface $db,
        private WalletService $wallet,
    ) {}

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $actor = RequestUtil::getActor($request);
        $actor->assertRegistered();

        $body = $request->getParsedBody();
        $carId = (int) ($body['car_id'] ?? 0);
        $bet = (int) ($body['bet'] ?? 0);
        $challengedUserId = isset($body['challenged_user_id']) ? (int) $body['challenged_user_id'] : null;

        if (!$carId) {
            return new JsonResponse(['error' => 'Select a car'], 422);
        }

        // Verify user owns this car
        $car = $this->db->table('racing_user_cars')
            ->where('id', $carId)
            ->where('user_id', $actor->id)
            ->first();

        if (!$car) {
            return new JsonResponse(['error' => 'Car not found in your garage'], 404);
        }

        // Bet validation
        if ($bet < 0) {
            return new JsonResponse(['error' => 'Bet cannot be negative'], 422);
        }

        if ($bet > 0) {
            $balance = $this->wallet->getBalance($actor->id);
            if ($balance < $bet) {
                return new JsonResponse(['error' => 'Insufficient coins for this bet'], 422);
            }
        }

        // Check no duplicate open challenge
        $existing = $this->db->table('racing_challenges')
            ->where('challenger_id', $actor->id)
            ->where('status', 'pending')
            ->exists();

        if ($existing) {
            return new JsonResponse(['error' => 'You already have an open challenge. Cancel it first.'], 422);
        }

        $id = $this->db->table('racing_challenges')->insertGetId([
            'challenger_id' => $actor->id,
            'challenged_id' => $challengedUserId,
            'challenger_car_id' => $carId,
            'bet' => $bet,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return new JsonResponse([
            'success' => true,
            'challenge_id' => $id,
            'message' => $challengedUserId
                ? 'Challenge sent!'
                : 'Challenge posted to lobby!',
        ]);
    }
}
