<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;

return [
    'up' => function (Builder $schema) {
        // User wallets
        if (!$schema->hasTable('racing_wallets')) {
            $schema->create('racing_wallets', function (Blueprint $table) {
                $table->increments('id');
                $table->unsignedInteger('user_id')->unique();
                $table->unsignedBigInteger('balance')->default(0);
                $table->timestamps();
                $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            });
        }

        // Car definitions (catalog)
        if (!$schema->hasTable('racing_car_catalog')) {
            $schema->create('racing_car_catalog', function (Blueprint $table) {
                $table->increments('id');
                $table->string('name');
                $table->string('emoji', 10)->default('🚗');
                $table->string('color', 7)->default('#ff0000');
                $table->unsignedInteger('price');
                $table->unsignedTinyInteger('speed');       // 1-100
                $table->unsignedTinyInteger('acceleration'); // 1-100
                $table->unsignedTinyInteger('handling');    // 1-100
                $table->unsignedTinyInteger('luck');        // 1-100
                $table->string('rarity')->default('common'); // common, rare, epic, legendary
                $table->boolean('available')->default(true);
                $table->timestamps();
            });
        }

        // User's owned cars
        if (!$schema->hasTable('racing_user_cars')) {
            $schema->create('racing_user_cars', function (Blueprint $table) {
                $table->increments('id');
                $table->unsignedInteger('user_id');
                $table->unsignedInteger('car_catalog_id');
                $table->string('custom_name')->nullable();
                $table->unsignedInteger('races_total')->default(0);
                $table->unsignedInteger('races_won')->default(0);
                $table->timestamps();
                $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
                $table->foreign('car_catalog_id')->references('id')->on('racing_car_catalog')->onDelete('cascade');
            });
        }

        // Challenges / lobby
        if (!$schema->hasTable('racing_challenges')) {
            $schema->create('racing_challenges', function (Blueprint $table) {
                $table->increments('id');
                $table->unsignedInteger('challenger_id');
                $table->unsignedInteger('challenged_id')->nullable(); // null = open challenge
                $table->unsignedInteger('challenger_car_id');
                $table->unsignedInteger('challenged_car_id')->nullable();
                $table->unsignedBigInteger('bet')->default(0);
                $table->string('status')->default('pending'); // pending, accepted, declined, completed
                $table->timestamps();
                $table->foreign('challenger_id')->references('id')->on('users')->onDelete('cascade');
                $table->foreign('challenged_id')->references('id')->on('users')->onDelete('cascade');
            });
        }

        // Race results
        if (!$schema->hasTable('racing_races')) {
            $schema->create('racing_races', function (Blueprint $table) {
                $table->increments('id');
                $table->unsignedInteger('challenge_id');
                $table->unsignedInteger('winner_id');
                $table->unsignedInteger('loser_id');
                $table->unsignedInteger('winner_car_id');
                $table->unsignedInteger('loser_car_id');
                $table->unsignedBigInteger('prize');
                $table->json('race_log'); // step-by-step race events
                $table->timestamps();
                $table->foreign('challenge_id')->references('id')->on('racing_challenges')->onDelete('cascade');
            });
        }
    },

    'down' => function (Builder $schema) {
        $schema->dropIfExists('racing_races');
        $schema->dropIfExists('racing_challenges');
        $schema->dropIfExists('racing_user_cars');
        $schema->dropIfExists('racing_car_catalog');
        $schema->dropIfExists('racing_wallets');
    },
];
