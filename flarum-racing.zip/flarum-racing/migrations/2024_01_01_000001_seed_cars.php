<?php

use Illuminate\Database\Schema\Builder;

return [
    'up' => function (Builder $schema) {
        $db = $schema->getConnection();

        $cars = [
            // Common cars
            [
                'name' => 'Rusty Hatchback',
                'emoji' => '🚗',
                'color' => '#888888',
                'price' => 100,
                'speed' => 30,
                'acceleration' => 25,
                'handling' => 35,
                'luck' => 20,
                'rarity' => 'common',
                'available' => true,
            ],
            [
                'name' => 'City Sedan',
                'emoji' => '🚙',
                'color' => '#4a90d9',
                'price' => 200,
                'speed' => 40,
                'acceleration' => 35,
                'handling' => 40,
                'luck' => 25,
                'rarity' => 'common',
                'available' => true,
            ],
            [
                'name' => 'Sport Coupe',
                'emoji' => '🏎',
                'color' => '#e74c3c',
                'price' => 500,
                'speed' => 60,
                'acceleration' => 55,
                'handling' => 50,
                'luck' => 30,
                'rarity' => 'rare',
                'available' => true,
            ],
            [
                'name' => 'Muscle Car',
                'emoji' => '🚘',
                'color' => '#f39c12',
                'price' => 750,
                'speed' => 70,
                'acceleration' => 65,
                'handling' => 40,
                'luck' => 35,
                'rarity' => 'rare',
                'available' => true,
            ],
            [
                'name' => 'Supercar X',
                'emoji' => '🏁',
                'color' => '#9b59b6',
                'price' => 2000,
                'speed' => 85,
                'acceleration' => 80,
                'handling' => 75,
                'luck' => 50,
                'rarity' => 'epic',
                'available' => true,
            ],
            [
                'name' => 'Golden Rocket',
                'emoji' => '⚡',
                'color' => '#f1c40f',
                'price' => 5000,
                'speed' => 95,
                'acceleration' => 90,
                'handling' => 85,
                'luck' => 70,
                'rarity' => 'legendary',
                'available' => true,
            ],
        ];

        foreach ($cars as $car) {
            $db->table('racing_car_catalog')->insertOrIgnore(array_merge($car, [
                'created_at' => now(),
                'updated_at' => now(),
            ]));
        }
    },

    'down' => function (Builder $schema) {
        $schema->getConnection()->table('racing_car_catalog')->truncate();
    },
];
